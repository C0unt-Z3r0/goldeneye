"""Utilitarios - config, logging, helpers."""
